# Instructions  

  ** this file should contain student lesson instructions **

  _ students will see these instructions in a read-only workspace tab _

  ## Steps
  1. 
  2. 
  3. 

  Use [Markdown](https://gist.github.com/cuonggt/9b7d08a597b167299f0d) to format your instructions.

  For example, here is a code block in python3
```python
def hello_world():
  print("hello world!")
```


  Include an image by placing it in the `assets` folder.

  For example, here is the Replit logo:

  ![alt text](assets/logo.png)
  
  